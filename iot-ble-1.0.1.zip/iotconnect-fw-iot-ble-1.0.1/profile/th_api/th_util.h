/*
 * Copyright (C) 2015-2017 EEMBC(R). All Rights Reserved
 * 
 * All EEMBC Benchmark Software are products of EEMBC and are provided under the
 * terms of the EEMBC Benchmark License Agreements. The EEMBC Benchmark Software
 * are proprietary intellectual properties of EEMBC and its Members and is
 * protected under all applicable laws, including all applicable copyright laws.  
 * 
 * If you received this EEMBC Benchmark Software without having a currently
 * effective EEMBC Benchmark License Agreement, you must discontinue use.
 */

#ifndef __TH_UTIL_H
#define __TH_UTIL_H

#include "ee_main.h"

void th_register_interval_callback(void (*)(void), unsigned);
void th_unregister_interval_callback(void);
void th_timeout_deepsleep(void (*)(void), unsigned);
void th_profile_initialize(void);
uint8_t th_lpf(uint8_t s1, uint8_t s2);
void th_uuid(void);
uint8_t * th_buffer_address(void);
void th_pre(void);
void th_post(void);

#endif
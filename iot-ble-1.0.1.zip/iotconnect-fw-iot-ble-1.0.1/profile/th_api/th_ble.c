/*
 * Copyright (C) 2015-2017 EEMBC(R). All Rights Reserved
 * 
 * All EEMBC Benchmark Software are products of EEMBC and are provided under the
 * terms of the EEMBC Benchmark License Agreements. The EEMBC Benchmark Software
 * are proprietary intellectual properties of EEMBC and its Members and is
 * protected under all applicable laws, including all applicable copyright laws.  
 * 
 * If you received this EEMBC Benchmark Software without having a currently
 * effective EEMBC Benchmark License Agreement, you must discontinue use.
 */

#include "th_ble.h"

/**
 * This local table defines all the available Tx transmit power levels the
 * developer wishes to expose. Entry 0 is always 0 dBm or close as possible,
 * e.g., the level we test at as defined by the workgroup vote.
 */
static char * tx_powers[] = {
	/**
	 * It is OK to change this string if your device doesn't support 0dBm, but
	 * please leave the (certification) in so that the user isn't confused.
	 */
	"0 dBm (certification)"
	/**
	 * Add additional level descriptions here, switch/case below resolves.
	 */
};
static size_t num_tx_powers = sizeof(tx_powers) / sizeof(char *);

/**
 * PORTME: Create the BLE interface if not already done
 */
void
th_ble_initialize(void) {
}

/**
 * PORTME: Start advertising at the requested interval (ms).
 *
 * The interval may be the following
 *
 * 0 : stop advertising
 * N : advertising interval
 *
 * The nonzero advertising interval is pre-qualified before by the
 * profile command parser to be in the range of [20, 10240]ms
 *
 * ADVERTISING AND SCAN RULES:
 *
 * 1. You must advertise on all three channels
 * 2. You must present a connectable advertise
 * 3. It is OK to use the minium 3 byte advertise payload
 * 4. The name is returned in the scan response (#define SCAN_NAME in th_ble.h)
 */
void
th_ble_advertise(unsigned interval_ms) {
	#warning "th_ble_advertise() not implemented"
}

/**
 * PORTME: Send the notification characteristic's bytes.
 */
void
th_ble_notify(uint8_t *payload, unsigned length) {
	#warning "th_ble_notify() not implemented"
}

/**
 * PORTME: Install this callback to handle when the DUT receives a command write
 * Provide a pointer to the payload bytes, and how many bytes were received.
 */
void
th_ble_register_command_callback(void (*callback)(uint8_t *bytes, unsigned num)) {
	#warning "th_ble_register_command_callback() not implemented"
}

/**
 * PORTME: Remove the command callback previously registered
 */
void
th_ble_unregister_command_callback(void) {
	#warning "th_ble_unregister_command_callback() not implemented"
}

/**
 * Note this is an ee_* function. It prints out a table of strings used by the
 * host to offer various power levels to the user. It needs to be in this
 * format.
 */
void
ee_ble_print_tx_power_table(void) {
	for (size_t i = 0; i < num_tx_powers; ++i) {
		th_printf("m-txpower-%d-[%s]\r\n", i, tx_powers[i]);
	}
}

/**
 * PORTME: This functions sets the Tx power according to the 0-based index
 * defined at the top of this file in the "tx_powers" array.
 *
 * Input: Index into tx power table; 0 = default power
 * Return: Text description if valid index, NULL otherwise
 */
char *
th_ble_set_tx_power(unsigned int val) {
	if (val > num_tx_powers) {
		return NULL;
	}
	switch (val) {
		case 0: // default certification power, 0 dBm or as close
		default:
			#warning "th_ble_set_tx_power() implementation not finished"
	}
	return tx_powers[val];
}


/**
 * Call this function when the stack connects.
 */
void
ee_ble_connect_callback(void) {
	th_printf("m-ble-connected\r\n");
}

/**
 * Call this function when the stack disconnects.
 */
void
ee_ble_disconnect_callback(void) {
	th_printf("m-ble-disconnected\r\n");
}



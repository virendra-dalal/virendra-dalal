/*
 * Copyright (C) 2015-2017 EEMBC(R). All Rights Reserved
 * 
 * All EEMBC Benchmark Software are products of EEMBC and are provided under the
 * terms of the EEMBC Benchmark License Agreements. The EEMBC Benchmark Software
 * are proprietary intellectual properties of EEMBC and its Members and is
 * protected under all applicable laws, including all applicable copyright laws.  
 * 
 * If you received this EEMBC Benchmark Software without having a currently
 * effective EEMBC Benchmark License Agreement, you must discontinue use.
 */

#ifndef __TH_BLE_H
#define __TH_BLE_H

#include "ee_main.h"

#define SCAN_NAME "IOTMARK-BLE"

void th_ble_initialize(void);
void th_ble_advertise(unsigned);
void th_ble_notify(uint8_t *, unsigned);
void th_ble_register_command_callback(void (*)(uint8_t *, unsigned));
void th_ble_unregister_command_callback(void);
void ee_ble_print_tx_power_table(void);
char * th_ble_set_tx_power(unsigned int);
void ee_ble_connect_callback(void);
void ee_ble_disconnect_callback(void);

#endif

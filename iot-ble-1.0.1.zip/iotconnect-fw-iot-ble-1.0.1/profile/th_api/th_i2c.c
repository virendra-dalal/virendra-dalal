/*
 * Copyright (C) 2015-2017 EEMBC(R). All Rights Reserved
 * 
 * All EEMBC Benchmark Software are products of EEMBC and are provided under the
 * terms of the EEMBC Benchmark License Agreements. The EEMBC Benchmark Software
 * are proprietary intellectual properties of EEMBC and its Members and is
 * protected under all applicable laws, including all applicable copyright laws.  
 * 
 * If you received this EEMBC Benchmark Software without having a currently
 * effective EEMBC Benchmark License Agreement, you must discontinue use.
 */

#include "th_i2c.h"

/**
 * PORTME: Create the I2C interface if not already done
 */
void
th_i2c_initialize(void) {
}

/**
 * PORTME: Set the I2C transfer speed, either 100kHz or 400kHz
 * 
 * Input: if b != 0, use 400k, if b = 0, use 100k
 */
void
th_i2c_set_speed(int b) {
	#warning "th_i2c_set_speed() not implemented"
}

/**
 * PORTME: Read a number of bytes from the I2C interface
 */
void
th_i2c_read(uint8_t *buffer, unsigned length) {
	#warning "th_i2c_read() not implemented"
}

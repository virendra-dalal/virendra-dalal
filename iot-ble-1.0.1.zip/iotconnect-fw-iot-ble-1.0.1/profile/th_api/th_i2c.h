/*
 * Copyright (C) 2015-2017 EEMBC(R). All Rights Reserved
 * 
 * All EEMBC Benchmark Software are products of EEMBC and are provided under the
 * terms of the EEMBC Benchmark License Agreements. The EEMBC Benchmark Software
 * are proprietary intellectual properties of EEMBC and its Members and is
 * protected under all applicable laws, including all applicable copyright laws.  
 * 
 * If you received this EEMBC Benchmark Software without having a currently
 * effective EEMBC Benchmark License Agreement, you must discontinue use.
 */

#ifndef __TH_I2C_H
#define __TH_I2C_H

#include "ee_main.h"

void th_i2c_initialize(void);
void th_i2c_set_speed(int);
void th_i2c_read(uint8_t *, unsigned);

#endif
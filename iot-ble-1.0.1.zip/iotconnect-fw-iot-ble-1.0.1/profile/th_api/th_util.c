/*
 * Copyright (C) 2015-2017 EEMBC(R). All Rights Reserved
 * 
 * All EEMBC Benchmark Software are products of EEMBC and are provided under the
 * terms of the EEMBC Benchmark License Agreements. The EEMBC Benchmark Software
 * are proprietary intellectual properties of EEMBC and its Members and is
 * protected under all applicable laws, including all applicable copyright laws.  
 * 
 * If you received this EEMBC Benchmark Software without having a currently
 * effective EEMBC Benchmark License Agreement, you must discontinue use.
 */

#include "th_util.h"

/* globals */
// See comments in th_buffer_address() below for details on this:
static uint8_t g_generic_byte_buffer[4096];

/**
 * PORTME: Create/Start a periodic call to "callback" every "ms" millseconds
 */
void
th_register_interval_callback(void (*callback)(void), unsigned ms) {
	#warning "th_register_interval_callback() not implemented"
}

/**
 * PORTME: Stop/Destroy the mechanism created with the function above
 */
void
th_unregister_interval_callback(void) {
	#warning "th_unregister_interval_callback() not implemented"
}

/**
 * PORTME: Go into a low-power/deep-sleep mode for N ms and call a callback
 */
void
th_timeout_deepsleep(void (*callback)(void), unsigned ms) {
	#warning "th_timeout_deepsleep() not implemented"
}

/** 
 * PORTME: Any last initialization for the profile-specific code goes here
 */
void
th_profile_initialize(void) {
}

/**
 * This is the fixed-point LPF function. Feel free to provide a faster but
 * bit-accurate version; the results are checked by the host during testing.
 *
 * Taken from:
 * http://www.hackersdelight.org/divcMore.pdf
 * Adjunct to "Hacker's Delight (Addison-Wesley, 2003, 2012)"
 */
uint8_t
th_lpf(uint8_t s1, uint8_t s2) {
    uint32_t q, r, n;
    n = (((uint32_t)s2)<<2) + (uint32_t)s1;
    q = (n>>3) + (n>>4);
    q = q + (q >> 4);
    q = q + (q >> 8);
    q = q + (q >> 16);
    r = n - q * 5;
    return (uint8_t)(q + (13*r >> 6));
}

/**
 * PORTME: Return the UUID in the format: "m-uuid-xx:xx:xx:xx:xx:xx\r\n"
 * ... where x is a hex digit and leading zeroes are included
 */
void
th_uuid(void) {
    #warning "th_uuid() not implemented"
    // for example:
    //th_printf("m-uuid-%02x:%02x:%02x:%02x:%02x:%02x\r\n", ... etc ...);
}

/**
 * The profile needs a (up to) 1KB buffer for I2C bytes. This can be static
 * (implemented here), or dynamic (using th_monitor_initialize), it is up
 * to the developer. The benchmark only requires 256B, but the UI will 
 * accept up to 1024B for additional analysis (unrelated to the offical score).
 * It is totally optional to provide the full 1KB.
 */
uint8_t *
th_buffer_address(void) {
    return g_generic_byte_buffer;
}

/**
 * The pre/post hooks are called immediately after the th_timestamp() and
 * immediately before. These hooks give the developer a chance to turn off
 * certain features (like UART) to save power during the loop.
 */

void
th_pre(void) {
}

void
th_post(void) {
}

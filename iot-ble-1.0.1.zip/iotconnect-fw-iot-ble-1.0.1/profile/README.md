# Introduction

This is the IoTMark(tm)-BLE profile. It implements the firmware routines used to measure standby, advertise and connect power as defined in the IoTConnect UI for IoTMark-BLE.

# Porting

In addition to porting the `monitor` API, port these profile-specific functions, also:

File: `th_api/th_ble.c`:
1. `th_ble_initialize` (optional) - Create the BLE interface if not already done
2. `th_ble_advertise` - Start advertising at the requested interval (ms), or stop advertising
3. `th_ble_notify` - Send the notification characteristic's bytes
4. `th_ble_register_command_callback` - Install this callback to handle when the DUT receives a command write
5. `th_ble_unregister_command_callback` - Remove the command callback previously registered
6. `th_ble_set_tx_power` - This functions sets the Tx power according to the 0-based index defined at the top of this file in the "tx_powers" array.

File: `th_api/th_i2c.c`:
1. `th_i2c_initialize` (optional) - Create the I2C interface if not already done
2. `th_i2c_set_speed` - Set the I2C transfer speed, either 100kHz or 400kHz
3. `th_i2c_read` - Read a number of bytes from the I2C interface

File: `th_api/th_util.c`:
1. `th_register_interval_callback` - Create/Start a periodic call to "callback" every "ms" millseconds
2. `th_unregister_interval_callback` - Stop/Destroy the mechanism created with the function above
3. `th_timeout_deepsleep` - Go into a low-power/deep-sleep mode for N ms and call a callback
4. `th_profile_initialize` (optional) - Any last initialization for the profile-specific code goes here
5. `th_uuid` - Return the UUID in the format: "m-uuid-xx:xx:xx:xx:xx:xx\r\n", where x is a hex digit and leading zeroes are included
5. `th_buffer_address` (optional) - return a pointer to a buffer to receive I2C bytes
5. `th_pre` (optional) - Implement any power optimizations after the `th_timestamp` funciton in the profile
6. `th_post` (optional) - See above, but before the closing `th_timestamp`

Each function has a description in the source file next to the comment `PORTME`. In addition `#warning` pre-processor directives are used to ensure the functions haven't accidentally been overlooked.

# BLE GATT

The benchmark expects the device to report one service and two characteristics, as follows:

| Service ID | Service Name | 
| --- | --- |
| 0xf2e0 | Data Transfer |

| Characteristic | Name | Property | Requirement | Security | Descriptors |
| --- | --- | --- | --- | --- | --- |
| 0xf2e1 | Data Transfer Tx | Notify | Mandatory | None | None |
| 0xf2e2 | Data Transfer Rx | Write Without Repsonse | Mandatory | None | None |

ALl other characteristic properties are excluded. Notify is 8B, command write is 64B.

The Host UI allows the user to specify the BLE 6-byte BD, which is used by the Radio Manager to identify and connect to the device.

# Advertising and Scan Rules

1. You must advertise on all three channels
2. You must present a connectable advertise
3. It is OK to use the minium 3 byte advertise payload
4. The name is returned in the scan response (#define SCAN_NAME in th_ble.h)

# Run Rules

A valid run must adhere to these rules prior to submission.

** PENDING VOTE **

1. Transmit power at 0dBm +/- 3dBm
2. Temperature min 21C
3. Not allowed any other source of energy other than Energy Monitor
4. Must use “typical” silicon rule which means no cherry picking extreme SKU devices
5. Must be publicly available board so that anyone can reproduce the scores if they license the benchmark, EEMBC “policing” strategy, no way to tell if it accurate
6. OK to remove jumpers, solder bridges, cut traces, remove chips on board and all modifications must be documented in the platform configuration guide required in the submission document
7. Voltage: Fixed at 3.0V required + optional lower voltage (just like ULPMark)
8. Score collected with default parameters (I2C -> 400khz, etc).  Must use the restore default button prior to running the test and submitting scores.

# Introduction

This repository contains the firmware for all benchmarks based on IoTConnect. The `master` branch contains only the monitor, with external linkage for the profile.

There are multiple *significant branches* that define the firmware for each benchmark. They are to be checked out as branches with `-b`, and are not their own repository since they all require the same `monitor` code.

Think of the master branch as an abstract base class in C++ and each significant branch as a derived class.

# Porting

The primary entry point to the monitor is `ee_main()`. This function initializes the framework. The secondary entry point is a callback to `ee_serial_callback()`. This function should be connected to the UART connected to the IO Manager and called every time a new character appears on the UART (most likely this is done by an ISR to save energy, but it could also appear in a polling loop). The callback appends each new character to an 80 byte buffer; when it receives a terminator character--a percent `%` sign--the string is dispatched to `ee_serial_command_parser_callback()` for routing and execution. Since the callback should NEVER be called inside an ISR (because some commands may trigger operations that take minutes to complete), `ee_serial_callback()` calls a `th_command_ready()` and then let's the developer defer to call `ee_serial_command_parser_callback()` at a later time, hopefully not before the next character arrives.

While debugging the firmware, it can be useful to connect to the device with a serial app (*TeraTerm*, *PuTTY*, *screen*, *minicom*, etc.). By default the monitor runs at 9600 baud. For versions of the IoTConnect Framework using an Arduino UNO, 9600 is required.

Every command returns `m-ready\r\n` on completion indicating that the system is ready to parse another command. If the system is NOT ready to parse another command, don't issue `m-ready\r\n` otherwise this will break the host software(s). Errors must start with `e-`. All strings sent by `th_printf` must end with CRLF, or `\r\n`.

The following API functions are required to meet the basic functionality of the framework:

1. `th_timestamp` - Generates a falling edge, waiting at least 62.5ns to return to a high level 
2. `th_printf` - Behave's exactly like ANSI printf, but sends the results to the UART
3. `th_command_ready` - When the ISR calls `ee_serial_callback()` to add a character and check if a command was recieved, this command is called with a pointer to the command. It is then up to the developer to dispatch this command to `ee_serial_command_parse_callback()` outside the ISR. The implementation is left up to the developer.
4. `th_monitor_initialize` (optional) - Any additional initialization code can go in here; typically most developers initialize everything before calling ee_main().
5. `th_timestamp_initialize` (optional) - If the timestamp GPIO hasn't been initialized, it can be done here
6. `th_serialport_initialize` (optional) - If the serial port UART hasn't been initialized, it can be done here

# Profile

The main parse loop passes any unparsed comands to `ee_profile_parse()`. As stated above, each significant branch will implement the profile, so the master branch won't compile due to this missing dependency.

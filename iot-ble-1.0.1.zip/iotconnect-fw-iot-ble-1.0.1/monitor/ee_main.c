/*
 * Copyright (C) 2015-2017 EEMBC(R). All Rights Reserved
 *
 * All EEMBC Benchmark Software are products of EEMBC and are provided under the
 * terms of the EEMBC Benchmark License Agreements. The EEMBC Benchmark Software
 * are proprietary intellectual properties of EEMBC and its Members and is
 * protected under all applicable laws, including all applicable copyright laws.
 *
 * If you received this EEMBC Benchmark Software without having a currently
 * effective EEMBC Benchmark License Agreement, you must discontinue use.
 */

#include "ee_main.h"

/**
 * Static memory / variables:
 */

// Command buffer (incoming commands from host)
static char volatile g_cmd_buf[EE_CMD_SIZE + 1];
static int volatile g_cmd_pos = 0;
// Since the serial port ISR may be connected before the loop is ready, this
// flag turns off the parser until the main routine is ready.
static int g_parser_enabled = 0;

/**
 * This function assembles a command string from the UART. It should be called
 * from the UART ISR for each new character received. When the parser sees the
 * termination character, the user-defined th_command_ready() command is called.
 * It is up to the application to then dispatch this command outside the ISR
 * as soon as possible by calling ee_serial_command_parser_callback(), below.
 */
void
ee_serial_callback(char c) {
	if (c == EE_CMD_TERMINATOR) {
		g_cmd_buf[g_cmd_pos] = 0;
		th_command_ready(g_cmd_buf);
		g_cmd_pos = 0;
	} else {
		g_cmd_buf[g_cmd_pos] = c;
		g_cmd_pos = g_cmd_pos >= EE_CMD_SIZE ? EE_CMD_SIZE : g_cmd_pos + 1;
	}
}

/**
 * This is the minimal parser required to test the monitor; profile-specific
 * commands are handled by whatever profile is compiled into the firmware.
 *
 * The most basic commands are:
 *
 * name				Print m-name-NAME, where NAME defines the intent of the f/w
 * timestamp		Generate a signal used for timestamping by the framework
 */
void
ee_serial_command_parser_callback(char *command_string) {
	if (! g_parser_enabled) {
		return;
	}
	// Subsequent parsers simply proceed with th_strtok()
	char *command = th_strtok(command_string, EE_CMD_DELIMITER);
	if (! th_strcmp(command, "name")) {
		th_printf("m-name-%s-[%s]\r\n", EE_DEVICE_NAME, TH_VENDOR_NAME_STRING);
	} else if (! th_strcmp(command, "timestamp")) {
		th_timestamp();
	} else {
		if (ee_profile_parse(command)) {
			th_printf("e-command-?%s\r\n", command);
		}
	}
	/**
	 * "m-ready" indicates that the DUT is ready to accept and process another
	 * command.
	 */
	th_printf("m-ready\r\n");
}

/**
 * Perform the basic setup.
 */
void
ee_main(void) {
	th_serialport_initialize();
	th_timestamp_initialize();
	th_monitor_initialize();
	ee_profile_initialize();
	th_printf("m-init-done\r\n");
	// Enable the command parser here (the callback is connected)
	g_parser_enabled = 1;
	// At this point, the serial monitor should be up and running,
	th_printf("m-ready\r\n");
}

/**
 * Instead of passing return values in the functions, call this function if
 * there is an error in any of the above functions. Try to use this function if
 * at all possible in your framework to assist in debugging.
 */
void
ee_errorhalt(void) {
	th_printf("e-halt\r\n");
	while(1) {
	}
}

/**
 * @brief convert a hexidecimal string to a signed long
 * will not produce or process negative numbers except
 * to signal error.
 *
 * @param hex without decoration, case insensitive.
 *
 * @return -1 on error, or result (max (sizeof(long)*8)-1 bits)
 *
 * Provided by Steve Allen at Dialog Semiconductor
 */
long
ee_hexdec(char *hex) {
    char c;
    long dec = 0;
    long ret = 0;

    while (*hex && ret >= 0) {
        c = *hex++;
        if (c >= '0' && c <= '9') {
            dec = c - '0';
        } else if (c >= 'a' && c <= 'f') {
            dec = c - 'a' + 10;
        } else if (c >= 'A' && c <= 'F') {
            dec = c - 'A' + 10;
        } else {
            return -1;
        }
        ret = (ret << 4) + dec;
    }
    return ret;
}

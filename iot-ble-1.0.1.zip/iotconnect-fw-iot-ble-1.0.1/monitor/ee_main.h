#ifndef __EE_MAIN_H
#define __EE_MAIN_H

#include "th_api/th_lib.h"
#include "th_api/th_libc.h"

// A dev will never change this, only EEMBC can
#define EE_DEVICE_NAME "dut"
#define EE_CMD_SIZE 80
#define EE_CMD_DELIMITER "-"
#define EE_CMD_TERMINATOR '%'

void ee_serial_callback(char);
void ee_serial_command_parser_callback(char *);
void ee_main(void);
void ee_errorhalt(void);
long ee_hexdec(char *hex);
// Required to be implemented by EEMBC in profile/*/ee_profile.c
int  ee_profile_parse(char *);
void ee_profile_initialize(void);

#endif
/*
 * Copyright (C) 2015-2017 EEMBC(R). All Rights Reserved
 *
 * All EEMBC Benchmark Software are products of EEMBC and are provided under the
 * terms of the EEMBC Benchmark License Agreements. The EEMBC Benchmark Software
 * are proprietary intellectual properties of EEMBC and its Members and is
 * protected under all applicable laws, including all applicable copyright laws.
 *
 * If you received this EEMBC Benchmark Software without having a currently
 * effective EEMBC Benchmark License Agreement, you must discontinue use.
 */

#ifndef __PORT_LIB_H
#define __PORT_LIB_H

#include <stdio.h>
#include <stdint.h>
#include <stdarg.h>
#include "th_libc.h"

/** 
 * This string is used in the "name%" command. When the host UI starts a test,
 * it calles the "name%" command, and the result is captured in the log file.
 * It can be quite useful to have the device's name in the log file for future
 * reference or debug.
 */
#define TH_VENDOR_NAME_STRING "unspecified"

// th_lib.c
void th_monitor_initialize(void);
void th_timestamp_initialize(void);
void th_timestamp(void);
void th_serialport_initialize(void);
void th_printf(const char * fmt, ...);
void th_command_ready(char *);

#endif

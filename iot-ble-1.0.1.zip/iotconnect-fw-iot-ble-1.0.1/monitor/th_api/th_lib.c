/*
 * Copyright (C) 2015-2017 EEMBC(R). All Rights Reserved
 *
 * All EEMBC Benchmark Software are products of EEMBC and are provided under the
 * terms of the EEMBC Benchmark License Agreements. The EEMBC Benchmark Software
 * are proprietary intellectual properties of EEMBC and its Members and is
 * protected under all applicable laws, including all applicable copyright laws.
 *
 * If you received this EEMBC Benchmark Software without having a currently
 * effective EEMBC Benchmark License Agreement, you must discontinue use.
 */

#include "th_lib.h"

/**
 * PORTME: If there's anything else that needs to be done on init, do it here,
 * othewise OK to leave it alone.
 */
void
th_monitor_initialize(void) {
}

/**
 * PORTME: Set up an OPEN-DRAIN GPIO if it hasn't already been done,
 * otherwise it is OK to leave this alone.
 */
void
th_timestamp_initialize(void) {
	// Always call the timestamp on initialize so that the open-drain output
	// is set to "1" (so that we catch a falling edge)
	th_timestamp();
}

/**
 * PORTME: Generate a falling edge. Since GPIO pin is OPEN-DRAIN it is OK to
 * float and let the pullup resistor drive.
 *
 * NOTE: The hold time is 62.5ns.
 */
void
th_timestamp(void) {
	// pull pin low
	// set pin high
	#warning "th_timestamp() not implemented"
}

/**
 * PORTME: Set up a serialport at 9600 baud to use for communication to the
 * host system if it hasn't already been done, otherwise it is OK to leave this
 * blank.
 */
void
th_serialport_initialize(void) {
	// remember baud = 9600
}

/**
 * PORTME: Modify this function to call the proper printf and send to the
 * serial port.
 *
 * It may only be necessary to comment out this function and define
 * th_printf as printf and just rerout fputc();
 */
void
th_printf(const char* fmt, ...) {
	va_list args;
	va_start(args, fmt);
	th_vprintf(fmt, args);
	va_end(args);
}

/**
 * PORTME: This function is called with a pointer to the command built from the
 * ee_serial_callback() function during the ISR. It is up to the developer
 * to call ee_serial_command_parser_callback() at the next available non-ISR
 * clock with this command string.
 */
void
th_command_ready(char *command) {
	#warning "th_command_ready() not implemented"
}
